<?php
include('config.php');
session_start();

// Ensure professor is logged in
if (!isset($_SESSION['professor_logged_in'])) {
    header("Location: login.php");
    exit;
}

$professor_id = $_SESSION['professor_id']; // Assuming professor ID is stored in session
$building_id = $_SESSION['building_id'];
$success_message = "";
$error_message = "";
$edit_course = null;

// Handle course deletion
if (isset($_GET['delete']) && $_GET['delete'] != '') {
    $delete_id = (int)$_GET['delete'];
    $delete_stmt = $con->prepare("DELETE FROM courses WHERE id = ? AND professor_id = ?");
    $delete_stmt->bind_param("ii", $delete_id, $professor_id);
    if ($delete_stmt->execute()) {
        $success_message = "Course deleted successfully!";
    } else {
        $error_message = "Error deleting course.";
    }
}

// Handle edit course loading
if (isset($_GET['edit']) && $_GET['edit'] != '') {
    $edit_id = (int)$_GET['edit'];
    $edit_stmt = $con->prepare("SELECT * FROM courses WHERE id = ? AND professor_id = ?");
    $edit_stmt->bind_param("ii", $edit_id, $professor_id);
    $edit_stmt->execute();
    $edit_result = $edit_stmt->get_result();
    $edit_course = $edit_result->fetch_assoc();
}

// Handle form submission (Add or Update)
if (isset($_POST['submit_course'])) {
    $course_name = trim($_POST['course_name']);
    $credits = (int)$_POST['credits'];
    $lecture_hours = (int)$_POST['lecture_hours'];
    $tutorial_hours = (int)$_POST['tutorial_hours'];
    $practical_hours = (int)$_POST['practical_hours'];
    $students_enrolled = (int)$_POST['students_enrolled'];
    $semester_id = (int)$_POST['semester_id'];
    $requires_projector = (int)$_POST['requires_projector'];
    $course_type = isset($_POST['course_type']) ? trim($_POST['course_type']) : 'Regular'; // Default course type
    $course_id = isset($_POST['course_id']) ? (int)$_POST['course_id'] : 0;

    if ($course_id > 0) {
        // Update existing course - Fixed to match database schema
        $update_stmt = $con->prepare("UPDATE courses SET name=?, credits=?, lecture_hours=?, tutorial_hours=?, practical_hours=?, semester_id=?, building_id=?, students_enrolled=?, requires_projector=?, course_type=? WHERE id=? AND professor_id=?");
        $update_stmt->bind_param("siiiiiiiisii", $course_name, $credits, $lecture_hours, $tutorial_hours, $practical_hours, $semester_id, $building_id, $students_enrolled, $requires_projector, $course_type, $course_id, $professor_id);
        
        if ($update_stmt->execute()) {
            $success_message = "Course updated successfully!";
            $edit_course = null; // Clear edit mode
        } else {
            $error_message = "Error updating course: " . $con->error;
        }
    } else {
        // Add new course - Fixed to match database schema and parameter count
        $insert_stmt = $con->prepare("INSERT INTO courses (name, credits, lecture_hours, tutorial_hours, practical_hours, professor_id, semester_id, building_id, students_enrolled, requires_projector, course_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $insert_stmt->bind_param("siiiiiiiiis", $course_name, $credits, $lecture_hours, $tutorial_hours, $practical_hours, $professor_id, $semester_id, $building_id, $students_enrolled, $requires_projector, $course_type);
        
        if ($insert_stmt->execute()) {
            $success_message = "Course added successfully!";
        } else {
            $error_message = "Error adding course: " . $con->error;
        }
    }
}

// Fetch professor's courses with pagination
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$limit = 8;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;
$likeSearch = "%$search%";

// Count total matching courses for this professor
$countStmt = $con->prepare("
    SELECT COUNT(*) 
    FROM courses 
    WHERE professor_id = ? AND name LIKE ?
");
$countStmt->bind_param("is", $professor_id, $likeSearch);
$countStmt->execute();
$countResult = $countStmt->get_result()->fetch_row();
$total = $countResult[0];
$pages = ceil($total / $limit);

// Fetch course data with semester names
$stmt = $con->prepare("
    SELECT c.id, c.name AS course_name, c.credits, c.lecture_hours, c.tutorial_hours, 
           c.practical_hours, c.students_enrolled, c.requires_projector, c.course_type,
           s.name AS semester_name
    FROM courses c
    JOIN semester s ON c.semester_id = s.id
    WHERE c.professor_id = ? AND c.name LIKE ?
    ORDER BY c.id DESC
    LIMIT ?, ?
");
$stmt->bind_param("isii", $professor_id, $likeSearch, $start, $limit);
$stmt->execute();
$courses_result = $stmt->get_result();

// Fetch semesters for dropdown
$semesters = $con->query("SELECT * FROM semester ORDER BY name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Courses - Professor Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --light-bg: #f8f9fa;
            --card-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .main-container {
            background: white;
            border-radius: 20px;
            box-shadow: var(--card-shadow);
            margin: 20px auto;
            overflow: hidden;
        }

        .header-section {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 2rem;
            text-align: center;
        }

        .header-section h1 {
            margin: 0;
            font-weight: 300;
            font-size: 2.5rem;
        }

        .content-section {
            padding: 2rem;
        }

        .form-card {
            background: var(--light-bg);
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            border: none;
            box-shadow: var(--card-shadow);
        }

        .form-title {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            padding: 12px 15px;
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }

        .btn {
            border-radius: 10px;
            padding: 12px 25px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--secondary-color), #2980b9);
            border: none;
        }

        .btn-success {
            background: linear-gradient(135deg, var(--success-color), #229954);
            border: none;
        }

        .btn-warning {
            background: linear-gradient(135deg, var(--warning-color), #d68910);
            border: none;
        }

        .btn-danger {
            background: linear-gradient(135deg, var(--danger-color), #c0392b);
            border: none;
        }

        .courses-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: var(--card-shadow);
        }

        .table th {
            background: var(--primary-color);
            color: white;
            font-weight: 600;
            border: none;
            padding: 15px;
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
            border-color: #e9ecef;
        }

        .course-stats {
            background: white;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
            box-shadow: var(--card-shadow);
        }

        .stat-item {
            text-align: center;
            padding: 1rem;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--secondary-color);
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }

        .alert {
            border-radius: 10px;
            border: none;
        }

        .search-section {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--card-shadow);
        }

        .course-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .badge-projector {
            background: #e8f5e8;
            color: var(--success-color);
        }

        .badge-no-projector {
            background: #fff3cd;
            color: var(--warning-color);
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="main-container">
            <!-- Header Section -->
            <div class="header-section">
                <h1><i class="fas fa-graduation-cap"></i> My Courses</h1>
                <p class="mb-0">Manage your courses efficiently</p>
            </div>

            <div class="content-section">
                <!-- Success/Error Messages -->
                <?php if (!empty($success_message)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle"></i> <?= $success_message ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($error_message)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-circle"></i> <?= $error_message ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Statistics -->
                <div class="course-stats">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="stat-item">
                                <div class="stat-number"><?= $total ?></div>
                                <div class="stat-label">Total Courses</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="stat-item">
                                <div class="stat-number">
                                    <?php
                                    $projector_count = $con->prepare("SELECT COUNT(*) FROM courses WHERE professor_id = ? AND requires_projector = 1");
                                    $projector_count->bind_param("i", $professor_id);
                                    $projector_count->execute();
                                    echo $projector_count->get_result()->fetch_row()[0];
                                    ?>
                                </div>
                                <div class="stat-label">Require Projector</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="stat-item">
                                <div class="stat-number">
                                    <?php
                                    $total_students = $con->prepare("SELECT SUM(students_enrolled) FROM courses WHERE professor_id = ?");
                                    $total_students->bind_param("i", $professor_id);
                                    $total_students->execute();
                                    echo $total_students->get_result()->fetch_row()[0] ?? 0;
                                    ?>
                                </div>
                                <div class="stat-label">Total Students</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Course Form -->
                <div class="form-card">
                    <h3 class="form-title">
                        <i class="fas fa-<?= $edit_course ? 'edit' : 'plus' ?>"></i>
                        <?= $edit_course ? 'Edit Course' : 'Add New Course' ?>
                    </h3>
                    
                    <form method="POST" class="row g-3">
                        <?php if ($edit_course): ?>
                            <input type="hidden" name="course_id" value="<?= $edit_course['id'] ?>">
                        <?php endif; ?>

                        <div class="col-md-6">
                            <label class="form-label"><i class="fas fa-book"></i> Course Name</label>
                            <input type="text" class="form-control" name="course_name" 
                                   value="<?= $edit_course ? htmlspecialchars($edit_course['name']) : '' ?>" 
                                   placeholder="Enter course name" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label"><i class="fas fa-star"></i> Credits</label>
                            <input type="number" class="form-control" name="credits" 
                                   value="<?= $edit_course ? $edit_course['credits'] : '' ?>" 
                                   placeholder="Enter credits" required min="1">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Lecture Hours (L)</label>
                            <input type="number" class="form-control" name="lecture_hours" 
                                   value="<?= $edit_course ? $edit_course['lecture_hours'] : '' ?>" 
                                   placeholder="L" required min="0">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Tutorial Hours (T)</label>
                            <input type="number" class="form-control" name="tutorial_hours" 
                                   value="<?= $edit_course ? $edit_course['tutorial_hours'] : '' ?>" 
                                   placeholder="T" required min="0">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Practical Hours (P)</label>
                            <input type="number" class="form-control" name="practical_hours" 
                                   value="<?= $edit_course ? $edit_course['practical_hours'] : '' ?>" 
                                   placeholder="P" required min="0">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label"><i class="fas fa-users"></i> Students Enrolled</label>
                            <input type="number" class="form-control" name="students_enrolled" 
                                   value="<?= $edit_course ? $edit_course['students_enrolled'] : '' ?>" 
                                   placeholder="Students" required min="1">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label"><i class="fas fa-calendar"></i> Semester</label>
                            <select class="form-select" name="semester_id" required>
                                <option value="">Select Semester</option>
                                <?php
                                $semesters->data_seek(0); // Reset result pointer
                                while ($semester = $semesters->fetch_assoc()): ?>
                                    <option value="<?= $semester['id'] ?>" 
                                            <?= ($edit_course && $edit_course['semester_id'] == $semester['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($semester['name']) ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label"><i class="fas fa-video"></i> Requires Projector</label>
                            <select class="form-select" name="requires_projector" required>
                                <option value="1" <?= ($edit_course && $edit_course['requires_projector'] == 1) ? 'selected' : '' ?>>Yes</option>
                                <option value="0" <?= ($edit_course && $edit_course['requires_projector'] == 0) ? 'selected' : '' ?>>No</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label"><i class="fas fa-tag"></i> Course Type</label>
                            <select class="form-select" name="course_type" required>
                                <option value="Regular" <?= ($edit_course && $edit_course['course_type'] == 'Regular') ? 'selected' : '' ?>>Regular</option>
                                <option value="Elective" <?= ($edit_course && $edit_course['course_type'] == 'Elective') ? 'selected' : '' ?>>Elective</option>
                                <option value="Core" <?= ($edit_course && $edit_course['course_type'] == 'Core') ? 'selected' : '' ?>>Core</option>
                                <option value="Open Elective" <?= ($edit_course && $edit_course['course_type'] == 'Open Elective') ? 'selected' : '' ?>>Open Elective</option>
                            </select>
                        </div>

                        <div class="col-12">
                            <button type="submit" name="submit_course" class="btn btn-primary me-2">
                                <i class="fas fa-save"></i> <?= $edit_course ? 'Update Course' : 'Add Course' ?>
                            </button>
                            <?php if ($edit_course): ?>
                                <a href="?" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel Edit
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>

                <!-- Search Section -->
                <div class="search-section">
                    <form method="GET" class="row g-3 align-items-end">
                        <div class="col-md-8">
                            <label class="form-label"><i class="fas fa-search"></i> Search Courses</label>
                            <input type="text" class="form-control" name="search" 
                                   value="<?= htmlspecialchars($search) ?>" 
                                   placeholder="Search by course name...">
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-search"></i> Search
                            </button>
                            <a href="?" class="btn btn-outline-secondary">
                                <i class="fas fa-refresh"></i> Reset
                            </a>
                        </div>
                    </form>
                </div>

                <!-- Courses Table -->
                <div class="courses-table">
                    <?php if ($courses_result->num_rows > 0): ?>
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Course Name</th>
                                    <th>Semester</th>
                                    <th>Credits</th>
                                    <th>L-T-P</th>
                                    <th>Students</th>
                                    <th>Type</th>
                                    <th>Projector</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($course = $courses_result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($course['course_name']) ?></strong>
                                    </td>
                                    <td><?= htmlspecialchars($course['semester_name']) ?></td>
                                    <td><span class="badge bg-info"><?= $course['credits'] ?></span></td>
                                    <td><?= $course['lecture_hours'] ?>-<?= $course['tutorial_hours'] ?>-<?= $course['practical_hours'] ?></td>
                                    <td><i class="fas fa-users"></i> <?= $course['students_enrolled'] ?></td>
                                    <td><span class="badge bg-secondary"><?= htmlspecialchars($course['course_type']) ?></span></td>
                                    <td>
                                        <span class="course-badge <?= $course['requires_projector'] ? 'badge-projector' : 'badge-no-projector' ?>">
                                            <?= $course['requires_projector'] ? 'Yes' : 'No' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="?edit=<?= $course['id'] ?>" class="btn btn-warning btn-sm me-1">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="?delete=<?= $course['id'] ?>" class="btn btn-danger btn-sm" 
                                           onclick="return confirm('Are you sure you want to delete this course?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-book-open"></i>
                            <h4>No courses found</h4>
                            <p>You haven't added any courses yet or no courses match your search.</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Pagination -->
                <?php if ($pages > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php for ($i = 1; $i <= $pages; $i++): ?>
                            <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                                <a class="page-link" href="?search=<?= urlencode($search) ?>&page=<?= $i ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
                <?php endif; ?>

                <!-- Navigation -->
                <div class="text-center mt-4">
                    <a href="professor_dashboard.php" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-hide alerts after 5 seconds
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                if (alert.classList.contains('show')) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }
            });
        }, 5000);

        // Smooth scroll to form when editing
        <?php if ($edit_course): ?>
        document.querySelector('.form-card').scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
        <?php endif; ?>
    </script>
</body>
</html>